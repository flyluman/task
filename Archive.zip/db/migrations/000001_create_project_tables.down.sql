-- drop purchases table
DROP TABLE IF EXISTS purchases;

-- drop menu_items table
DROP TABLE IF EXISTS menu_items;

-- drop restaurants table
DROP TABLE IF EXISTS restaurants;

-- drop users table
DROP TABLE IF EXISTS users;
